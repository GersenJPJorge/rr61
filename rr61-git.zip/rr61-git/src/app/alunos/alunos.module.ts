import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// CommonModule é usado nas raizes por conta das diretivas
import { AlunosComponent } from './alunos.component';
import { AlunoFormComponent } from './aluno-form/aluno-form.component';
import { AlunoDetalheComponent } from './aluno-detalhe/aluno-detalhe.component';
import { AlunosService } from './alunos.service';
import { AlunosRoutingModule } from './alunos.routing.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
// O FormsModule é usado juntamente com o 'ngmodel' dos templates

@NgModule({
  declarations: [
    AlunosComponent,
    AlunoFormComponent,
    AlunoDetalheComponent,
  ],
  imports: [
      CommonModule,
      FormsModule,
      ReactiveFormsModule,
      AlunosRoutingModule,
           ],
  providers: [AlunosService],
  bootstrap: []
})
export class AlunosModule { }
