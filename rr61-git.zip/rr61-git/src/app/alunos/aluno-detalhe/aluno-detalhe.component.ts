import { AlunosModule } from './../alunos.module';
import { AlunosService } from './../alunos.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs/Rx';
import { Component, OnInit, OnDestroy } from '@angular/core';
@Component({
  selector: 'app-aluno-detalhe',
  templateUrl: './aluno-detalhe.component.html',
  styleUrls: ['./aluno-detalhe.component.css']
})
export class AlunoDetalheComponent implements OnInit {

  id: number;
  aluno: any;
  inscricao: Subscription;

  constructor(
    private route: ActivatedRoute,
    private router: Router,
    private alunosService: AlunosService,
  ) { }


  // tslint:disable-next-line:no-unused-expression
  ngOnInit () {[
    this.route.params.subscribe(
    (params: any) => {
        this.id = params['id'];

        this.aluno = this.alunosService.getAluno(this.id);

        if (this.aluno === null) {
           this.aluno = {}
        }
      }
    )
    },


editarContato() {
  this.router.navigate(['/alunos', this.aluno.id, 'editar']);
}
// this.router.navigate( Rotas imperativas tem que passar todos os paramentros);

ngOnDestroy() {
  this.inscricao.unsubscribe();
}
}
