import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-curso-nao-encontrado',
  templateUrl: './curso-nao-encontrado.component.html'
})
export class CursoNaoEncontradoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
