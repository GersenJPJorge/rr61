import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
// import { RouterModule } from '@angular/router';
// RouterModule é preciso por causa dos Routerlinks,
// mas nao precisa aqui porque já está sendom inportado em
// cursos.routing.module

import { CursosComponent } from './cursos.component';
import { CursoDetalheComponent } from './curso-detalhe/curso-detalhe.component';
import { CursoNaoEncontradoComponent } from './curso-nao-encontrado/curso-nao-encontrado.component';
import { CursosService } from './cursos.service';
import { CursosRoutingModule } from './cursos.routing.module';
// CommonModule é usado nas raizes por conta das diretivas


@NgModule({
  declarations: [
    CursosComponent,
    CursoDetalheComponent,
    CursoNaoEncontradoComponent
  ],
  imports: [
      CommonModule,
//      RouterModule,
      CursosRoutingModule
           ],
  providers: [CursosService],
  bootstrap: []
})
export class CursosModule { }
